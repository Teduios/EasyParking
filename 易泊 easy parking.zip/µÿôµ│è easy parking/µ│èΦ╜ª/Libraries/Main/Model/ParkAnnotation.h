//
//  ParkAnnotation.h
//  易停 easy parking
//
//  Created by tarena on 16/1/13.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>

@interface ParkAnnotation : NSObject<MKAnnotation>

//坐标/位置(必须)
@property (nonatomic, assign) CLLocationCoordinate2D coordinate;
//title/subtitle(可选)
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *subtitle;
@property (nonatomic, strong) UIImage *image;
@property (nonatomic, assign) int ccid;


@end
