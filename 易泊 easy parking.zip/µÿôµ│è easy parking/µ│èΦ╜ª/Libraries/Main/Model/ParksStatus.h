//
//  ParksStatus.h
//  易停 easy parking
//
//  Created by tarena on 16/1/22.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ParksStatus : NSObject

@property (nonatomic, strong) NSString *CCID;
@property (nonatomic, strong) NSString *KCWZT;
@property (nonatomic, strong) NSString *YCSJ;

@end
