//
//  ParkNearbyParks.h
//  易停 easy parking
//
//  Created by tarena on 16/1/13.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ParkNearbyParks : NSObject

/** 停车场地址 */
@property (nonatomic, strong) NSString *CCDZ;
/** 停车场分类 */
@property (nonatomic, strong) NSString *CCFL;
/** 停车场ID */
@property (nonatomic, strong) NSString *CCID;
/** 停车场类型 */
@property (nonatomic, strong) NSString *CCLX;
/** 停车场名称 */
@property (nonatomic, strong) NSString *CCMC;
/** 停车场图片 */
@property (nonatomic, strong) NSString *CCTP;
/** 停车场坐标-经度 */
@property (nonatomic, assign) double JD;
/** 空车位 */
@property (nonatomic, strong) NSString *KCW;
/** 空车位状态 */
@property (nonatomic, strong) NSString *KCWZT;
/** 城市名 */
@property (nonatomic, strong) NSString *QYCS;
/** 停车场坐标-纬度 */
@property (nonatomic, assign) double WD;
/** 总车位 */
@property (nonatomic, strong) NSString *ZCW;



@end
