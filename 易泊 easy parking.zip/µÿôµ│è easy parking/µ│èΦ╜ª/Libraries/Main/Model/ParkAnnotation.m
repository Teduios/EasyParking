//
//  ParkAnnotation.m
//  易停 easy parking
//
//  Created by tarena on 16/1/13.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ParkAnnotation.h"

@implementation ParkAnnotation

@end
