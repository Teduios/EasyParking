//
//  ParkNearbyParkDetails.h
//  易停 easy parking
//
//  Created by tarena on 16/1/15.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ParkNearbyParkDetails : NSObject

/** 白天停车价格 */
@property (nonatomic, strong) NSString *BTTCJG;
/** 停车场地址 */
@property (nonatomic, strong) NSString *CCDZ;
/** 停车场分类 */
@property (nonatomic, strong) NSString *CCFL;
/** 停车场ID */
@property (nonatomic, strong) NSString *CCID;
/** 停车场类型 */
@property (nonatomic, strong) NSString *CCLX;
/** 停车场名称 */
@property (nonatomic, strong) NSString *CCMC;
/** 停车场图片 */
@property (nonatomic, strong) NSString *CCTP;
/** 计次收费-大型车[示例：10元/次、19：30-07：30(10元/次)] */
@property (nonatomic, strong) NSString *JCSFA;
/** 计次收费-小型车[示例：10元/次、19：30-07：30(10元/次)] */
@property (nonatomic, strong) NSString *JCSFB;
/** 经度 */
@property (nonatomic, assign) double JD;
/** 空车位 */
@property (nonatomic, assign) int KCW;
/** 停车场空车位状态图片 */
@property (nonatomic, strong) NSString *KCWZT;
/** 区域 */
@property (nonatomic, strong) NSString *QYCS;
/** 是否开放 */
@property (nonatomic, strong) NSString *SFKF;
/** 纬度 */
@property (nonatomic, assign) double WD;
/** 晚上停车价格 */
@property (nonatomic, strong) NSString *WSTCJG;
/** 营业结束时间（示例：19:00:00） */
@property (nonatomic, strong) NSString *YYJSSJ;
/** 营业开始时间（示例：06:00:00） */
@property (nonatomic, strong) NSString *YYKSSJ;
/** 总车位 */
@property (nonatomic, assign) int ZCW;

@end
