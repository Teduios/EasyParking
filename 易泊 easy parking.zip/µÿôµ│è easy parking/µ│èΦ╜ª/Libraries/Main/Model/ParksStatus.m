//
//  ParksStatus.m
//  易停 easy parking
//
//  Created by tarena on 16/1/22.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ParksStatus.h"

@implementation ParksStatus

@end
