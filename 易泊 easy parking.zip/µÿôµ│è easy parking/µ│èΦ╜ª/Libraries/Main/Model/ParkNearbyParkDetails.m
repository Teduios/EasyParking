//
//  ParkNearbyParkDetails.m
//  易停 easy parking
//
//  Created by tarena on 16/1/15.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ParkNearbyParkDetails.h"

@implementation ParkNearbyParkDetails

@end
