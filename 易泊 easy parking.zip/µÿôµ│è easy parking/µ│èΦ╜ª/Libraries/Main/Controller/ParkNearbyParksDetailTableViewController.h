//
//  ParkNearbyParksDetailTableViewController.h
//  易停 easy parking
//
//  Created by tarena on 16/1/18.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ParkNearbyParkDetails.h"

@interface ParkNearbyParksDetailTableViewController : UITableViewController
/** cell1属性 */
@property (weak, nonatomic) IBOutlet UILabel *parkNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *parkAddressLabel;
@property (weak, nonatomic) IBOutlet UILabel *totalParksNumberLabel;
@property (weak, nonatomic) IBOutlet UILabel *freeParksNumberLabel;

/** cell2属性 */
@property (weak, nonatomic) IBOutlet UILabel *dayCostLabel;
@property (weak, nonatomic) IBOutlet UILabel *nightCostLabel;
@property (weak, nonatomic) IBOutlet UILabel *businessHoursLabel;
@property (weak, nonatomic) IBOutlet UILabel *parkStatusLabel;

/** cell3属性 */
@property (weak, nonatomic) IBOutlet UILabel *parkCategoryLabel;
@property (weak, nonatomic) IBOutlet UILabel *parkTypeLabel;


/** 储存停车场基本信息 */
@property (nonatomic, strong) ParkNearbyParkDetails *baseInfo;


@end
