//
//  ParkNearbyParksDetailTableViewController.m
//  易停 easy parking
//
//  Created by tarena on 16/1/18.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ParkNearbyParksDetailTableViewController.h"
#import "ParkNearbyParkDetails.h"
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>
#import "MBProgressHUD+KR.h"
#import "AppDelegate.h"
#import "ParkFutureStatusTableViewController.h"
#import "AFNetworking.h"
#import "ParkDataManager.h"
#import "ParkMainViewController.h"

@interface ParkNearbyParksDetailTableViewController ()

@property (strong, nonatomic) IBOutlet UITableViewCell *cell1;
@property (strong, nonatomic) IBOutlet UITableViewCell *cell2;
@property (strong, nonatomic) IBOutlet UITableViewCell *cell3;
@property (strong, nonatomic) IBOutlet UITableViewCell *cell1_0;
@property (strong, nonatomic) IBOutlet UITableViewCell *cell1_2;

@property (nonatomic, strong) CLGeocoder *geoCoder;

@property (nonatomic, strong) NSArray *statusArray;


@end

@implementation ParkNearbyParksDetailTableViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.navigationItem.title = @"停车场详情";
    // 配置表头
    UIImageView *headerImageView = [[UIImageView alloc]init];
    headerImageView.frame = CGRectMake(0, 0, 0, 210);
    NSString *imageURL = [NSString stringWithFormat:@"http://images.juheapi.com/park/%@", self.baseInfo.CCTP];
    headerImageView.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:imageURL]]];
    
    self.tableView.tableHeaderView = headerImageView;
    
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(back)];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithTitle:@"收藏" style:UIBarButtonItemStylePlain target:self action:@selector(addToMyFavorite)];
    self.navigationItem.rightBarButtonItem = rightItem;
    
}

/** 点击收藏按钮 */
-(void)addToMyFavorite
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"收藏该停车场？" message:nil preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    UIAlertAction *doneAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        //收藏停车场
        [self clickDoneBtn];
    }];
    
    [alertController addAction:cancelAction];
    [alertController addAction:doneAction];
    [self presentViewController:alertController animated:YES completion:nil];
    
}

/** 收藏逻辑 */
-(void)clickDoneBtn
{
    NSString *myFavoriteParkPath = [DOCPATH stringByAppendingPathComponent:@"myFavorites.plist"];
    NSMutableArray *mutableArray = [NSMutableArray arrayWithContentsOfFile:myFavoriteParkPath];
    if (mutableArray == nil)
    {
        mutableArray = [NSMutableArray array];
    }
    NSDictionary *dictionary = [[NSDictionary alloc]initWithObjectsAndKeys:self.baseInfo.CCMC, @"CCMC",self.baseInfo.QYCS, @"QYCS", self.baseInfo.CCID, @"CCID", nil];
    for (NSDictionary *dic in mutableArray)
    {
        if ([dictionary[@"CCID"] isEqualToString:dic[@"CCID"]])
        {
            UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"已收藏过该停车场" message:nil preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *doneAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
            [alertController addAction:doneAction];
            [self presentViewController:alertController animated:YES completion:nil];

            return;
        }
    }
    [mutableArray addObject:dictionary];
    [mutableArray writeToFile:myFavoriteParkPath atomically:YES];
}


/** 返回之前页面 */
-(void)back
{
    [self dismissViewControllerAnimated:YES completion:nil];

}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    switch (section)
    {
        case 0:
            return 3;
        case 1:
            return 1;
        default:
            return 1;
    }
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if (section == 0)
    {
        return nil;
    }
    else if (section == 1)
    {
        return @"费用";
    }
    else
    {
        return @"分类";
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MYLog(@"baseInfo:%@", self.baseInfo);
    switch (indexPath.section)
    {
        case 0:
            if (indexPath.row == 0)
            {
                return self.cell1_0;
            }
            else if (indexPath.row == 1)
            {
                self.parkNameLabel.text = self.baseInfo.CCMC;
                self.parkAddressLabel.text = [NSString stringWithFormat:@"地址：%@ %@", self.baseInfo.QYCS, self.baseInfo.CCDZ];
                self.totalParksNumberLabel.text = [NSString stringWithFormat:@"总车位：%d", self.baseInfo.ZCW];
                self.freeParksNumberLabel.text = [NSString stringWithFormat:@"空车位：%d", self.baseInfo.KCW];
                
                return self.cell1;
            }
            else
            {
                return self.cell1_2;
            }
            
        case 1:
            self.dayCostLabel.text = [NSString stringWithFormat:@"白天：%@", self.baseInfo.BTTCJG];
            self.nightCostLabel.text = [NSString stringWithFormat:@"晚上：%@", self.baseInfo.WSTCJG];
            self.businessHoursLabel.text = [NSString stringWithFormat:@"营业时间：%@-%@", self.baseInfo.YYKSSJ, self.baseInfo.YYJSSJ];
            self.parkStatusLabel.text = (self.baseInfo.SFKF == 0) ? @"不开放" : @"开放中";
            return self.cell2;
            
        default:
            self.parkCategoryLabel.text = [NSString stringWithFormat:@"分类：%@", self.baseInfo.CCFL];
            self.parkTypeLabel.text = [NSString stringWithFormat:@"类型：%@", self.baseInfo.CCLX];
            
            return self.cell3;
    }
    
}

/** 设置行高 */
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    switch (indexPath.section)
    {
        case 0:
            if (indexPath.row == 0)
            {
                return 44;
            }
            else if (indexPath.row == 1)
            {
                return 120;
            }
            else
            {
                return 44;
            }
        case 1:
            return 140;
            
        default:
            return 65;
    }
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0;
}

/** 点击事件 */
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0)
    {
        if (indexPath.row == 0)
        {
            /** 点击规划路线 */
            NSDictionary *userInfoDic = [[NSDictionary alloc] initWithObjectsAndKeys:@(self.baseInfo.WD), @"WD", @(self.baseInfo.JD), @"JD", nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"drawLine" object:nil userInfo:userInfoDic];
            
            NSDictionary *userInfoDic2 = [[NSDictionary alloc] initWithObjectsAndKeys:@(self.baseInfo.WD), @"WD", @(self.baseInfo.JD), @"JD", self.baseInfo.CCMC, @"CCMC", nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:@"clickBtnToStartNavigate" object:nil userInfo:userInfoDic2];
            [self dismissViewControllerAnimated:YES completion:nil];
        }
        if (indexPath.row == 2)
        {
            [self sendRequestToServer];
        }
    }
}

/** 向服务器发请求 */
-(void)sendRequestToServer
{
    [MBProgressHUD showMessage:@"Loading..."];
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[@"key"] = APPKEY;
    parameters[@"CCID"] = self.baseInfo.CCID;
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager POST:FUTURE parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if ([responseObject isKindOfClass:[NSDictionary class]])
        {
            MYLog(@"responseObject ======= %@", responseObject);
            self.statusArray = [ParkDataManager getAndParseFutureStatusFromServer:responseObject];
            if (self.statusArray.count == 0)
            {
                [MBProgressHUD hideHUD];
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"暂无预测数据" message:nil preferredStyle:UIAlertControllerStyleAlert];
                UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
                [alertController addAction:action];
                [self presentViewController:alertController animated:YES completion:nil];
            }
            else
            {
                [MBProgressHUD hideHUD];
                [self goToFutureStatusTableViewController];
            }
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD showError:@"网络错误，请稍后再试"];
    }];
}

-(void)goToFutureStatusTableViewController
{
    /** 点击推出车位预测tableView */
    ParkFutureStatusTableViewController *futureStatusVC = [ParkFutureStatusTableViewController new];
    futureStatusVC.futureStatusArray = self.statusArray;
    UINavigationController *naviVC = [[UINavigationController alloc] initWithRootViewController:futureStatusVC];
    [self presentViewController:naviVC animated:YES completion:nil];
    
}
/** 点击去这里按钮，开始跳到高德导航 */
- (IBAction)startNavigate:(id)sender
{
    /** 点击开始导航 */
    CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(self.baseInfo.WD, self.baseInfo.JD);
    MKMapItem *currentItem = [MKMapItem mapItemForCurrentLocation];
    MKMapItem *parkItem = [[MKMapItem alloc] initWithPlacemark:[[MKPlacemark alloc] initWithCoordinate:coordinate addressDictionary:nil]];
    parkItem.name = self.baseInfo.CCMC;
    NSDictionary *options=@{MKLaunchOptionsMapTypeKey:@(MKMapTypeStandard),MKLaunchOptionsDirectionsModeKey:MKLaunchOptionsDirectionsModeDriving};
    [MKMapItem openMapsWithItems:@[currentItem, parkItem] launchOptions:options];
}

- (NSArray *)statusArray
{
	if(_statusArray == nil)
    {
		_statusArray = [NSArray array];
	}
	return _statusArray;
}

@end
