//
//  ParkMyFavoriteViewController.m
//  易停 easy parking
//
//  Created by tarena on 16/1/25.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ParkMyFavoriteViewController.h"
#import "AFNetworking.h"
#import "ParkDataManager.h"
#import "MBProgressHUD+KR.h"
#import "ParkNearbyParksDetailTableViewController.h"

@interface ParkMyFavoriteViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (weak, nonatomic) IBOutlet UIButton *editBtn;

@property (nonatomic, strong) NSMutableArray *favoriteParksArray;

@end

@implementation ParkMyFavoriteViewController

- (NSMutableArray *)favoriteParksArray
{
    if(_favoriteParksArray == nil)
    {
        _favoriteParksArray = [NSMutableArray array];
    }
    return _favoriteParksArray;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
}

- (IBAction)clickEditBtn:(id)sender
{
    [self.tableView setEditing:!self.tableView.editing animated:YES];
    [self.editBtn setTitle:self.tableView.editing?@"完成":@"编辑" forState:UIControlStateNormal];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    NSString *plistStr = [DOCPATH stringByAppendingPathComponent:@"myFavorites.plist"];
    NSArray *array = [NSArray arrayWithContentsOfFile:plistStr];
    self.favoriteParksArray = [array copy];
    [self.tableView reloadData];
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.favoriteParksArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"favoriteParkCell"];
    if (!cell)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"favoriteParkCell"];
    }
    NSDictionary *parksDic = [NSDictionary dictionary];
    parksDic = self.favoriteParksArray[indexPath.row];
    cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", parksDic[@"QYCS"], parksDic[@"CCMC"]];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [MBProgressHUD showMessage:@"正在加载..."];
    NSDictionary *parksDic = [NSDictionary dictionary];
    parksDic = self.favoriteParksArray[indexPath.row];
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[@"CCID"] = parksDic[@"CCID"];
    parameters[@"key"] = APPKEY;
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager POST:BASEINFO parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if ([responseObject isKindOfClass:[NSDictionary class]])
        {
            ParkNearbyParksDetailTableViewController *parkDetailVC = [ParkNearbyParksDetailTableViewController new];
            parkDetailVC.baseInfo = [ParkDataManager getAndParseAllBaseInfoFrom:responseObject];
            if (parkDetailVC.baseInfo != nil)
            {
                [MBProgressHUD hideHUD];
            }
            UINavigationController *navi = [[UINavigationController alloc] initWithRootViewController:parkDetailVC];
            [self presentViewController:navi animated:YES completion:nil];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD showError:@"网络错误，请稍后再试"];
    }];
    
}

#pragma mark - 编辑模式
-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}

-(NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return @"删除";
}

-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"删除提示" message:@"确认删除该停车场数据?" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
        UIAlertAction *doneAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
            //删除操作
            NSString *myFavoritesPath = [DOCPATH stringByAppendingPathComponent:@"myFavorites.plist"];
            self.favoriteParksArray = [NSMutableArray arrayWithContentsOfFile:myFavoritesPath];
            [self.favoriteParksArray removeObjectAtIndex:indexPath.row];
            //将删除后的数据保存
            [self.favoriteParksArray writeToFile:myFavoritesPath atomically:YES];
            [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        }];
        [alertController addAction:cancelAction];
        [alertController addAction:doneAction];
        [self presentViewController:alertController animated:YES completion:nil];
    }
    else if (editingStyle == UITableViewCellEditingStyleInsert)
    {
        
    }
}

@end
