//
//  ParkListViewController.m
//  易停 easy parking
//
//  Created by tarena on 16/1/21.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ParkListViewController.h"
#import "ParkNearbyParks.h"
#import "ParkNearbyParksDetailTableViewController.h"
#import "AFNetworking.h"
#import "MBProgressHUD+KR.h"
#import "ParkDataManager.h"

@interface ParkListViewController ()<UITableViewDelegate, UITableViewDataSource>


@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic, strong) NSArray *parksArray;

@end

@implementation ParkListViewController

- (NSArray *)parksArray
{
    if(_parksArray == nil)
    {
        _parksArray = [NSArray array];
    }
    return _parksArray;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self getParksFromPlist];
    [self.tableView reloadData];
}

-(NSArray *)getParksFromPlist
{
    NSString *parksArrayPath = [DOCPATH stringByAppendingPathComponent:@"parks.plist"];
    NSDictionary *dic = [NSDictionary  dictionaryWithContentsOfFile:parksArrayPath];
    NSArray *array = dic[@"result"];
    NSMutableArray *mutableArray = [NSMutableArray array];
    for (NSDictionary *parksDic in array)
    {
        ParkNearbyParks *parks = [ParkNearbyParks new];
        [parks setValuesForKeysWithDictionary:parksDic];
        [mutableArray addObject:parks];
    }
    self.parksArray = [mutableArray copy];
    return self.parksArray;
}

#pragma mark - tableView Delegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.parksArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"parkListCell"];
    if (!cell)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"parkListCell"];
    }
    
    ParkNearbyParks *parks = self.parksArray[indexPath.row];
    cell.textLabel.text = parks.CCMC;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"空车位：%@", parks.KCW];
    
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [MBProgressHUD showMessage:@"正在加载..."];
    ParkNearbyParks *parks = self.parksArray[indexPath.row];
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[@"key"] = APPKEY;
    parameters[@"CCID"] = parks.CCID;
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager POST:BASEINFO parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        MYLog(@"请求成功：%@", responseObject);
        /** 解析返回的数据 */
        if ([responseObject isKindOfClass:[NSDictionary class]])
        {
            ParkNearbyParkDetails *parkBaseInfo = [ParkDataManager getAndParseAllBaseInfoFrom:responseObject];
            MYLog(@"parkBaseInfo:%@", parkBaseInfo);
            ParkNearbyParksDetailTableViewController *parkDetailsVC = [ParkNearbyParksDetailTableViewController new];
            parkDetailsVC.baseInfo = parkBaseInfo;
            if (parkDetailsVC.baseInfo != nil)
            {
                [MBProgressHUD hideHUD];
            }
            UINavigationController *navi = [[UINavigationController alloc] initWithRootViewController:parkDetailsVC];
            [self presentViewController:navi animated:YES completion:nil];
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD showError:@"网络错误，请稍后再试"];
    }];
}



@end
