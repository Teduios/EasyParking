//
//  ParkMainViewController.m
//  易停 easy parking
//
//  Created by tarena on 16/1/12.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ParkMainViewController.h"
#import <MapKit/MapKit.h>
#import "AFNetworking.h"
#import "ParkDataManager.h"
#import "ParkAnnotation.h"
#import "ParkNearbyParks.h"
#import "ParkChangeCityTableViewController.h"
#import "ParkNearbyParksDetailTableViewController.h"
#import "MBProgressHUD+KR.h"

@interface ParkMainViewController ()<MKMapViewDelegate>

@property (weak, nonatomic) IBOutlet MKMapView *mapView;
@property (weak, nonatomic) IBOutlet UITextField *destinationTextField;
@property (weak, nonatomic) IBOutlet UILabel *cityNameLabel;
@property (weak, nonatomic) IBOutlet UIButton *naviButton;
@property (weak, nonatomic) IBOutlet UIView *selectView;

@property (nonatomic, strong) CLLocationManager *manager;
//地理编码
@property (nonatomic, strong) CLGeocoder *geocoder;
/** 接收附近的停车场数据的数组 */
@property (nonatomic, strong) NSArray *nearbyParksArray;
/** 用户位置 */
@property (nonatomic, strong) MKUserLocation *userLocation;
@property (nonatomic, strong) MKRoute *route;
@property (nonatomic, assign) CLLocationCoordinate2D naviCoordinate;
@property (nonatomic, strong) CLLocation *previousUserLocation;
@property (nonatomic, strong) NSString *parkItemName;
@property (nonatomic, assign) int category;
@property (nonatomic, assign) int distance;
@property (nonatomic, strong) UIButton *preCategoryButton;
@property (nonatomic, strong) UIButton *preDistanceButton;
@property (weak, nonatomic) IBOutlet UIButton *currentCategoryBtn;
@property (weak, nonatomic) IBOutlet UIButton *currentDistanceBtn;
@property (nonatomic, strong) ParkNearbyParkDetails *parkBaseInfo;

@end

@implementation ParkMainViewController

/** 点击停车场分类按钮 */
- (IBAction)clickParkCategoryBtn:(UIButton *)sender
{
    MYLog(@"tag = %ld", sender.tag);
    if (sender == self.preCategoryButton)
    {
        return;
    }
    self.currentCategoryBtn.selected = NO;
    self.currentCategoryBtn = sender;
    self.preCategoryButton.selected = NO;
    sender.selected = YES;
    self.preCategoryButton = self.currentCategoryBtn;
    self.category = (int)self.currentCategoryBtn.tag;
    
}

/** 点击停车场距离按钮 */
- (IBAction)clickDistanceBtn:(UIButton *)sender
{
    MYLog(@"tag = %ld", sender.tag);
    if (sender == self.preDistanceButton)
    {
        return;
    }
    self.currentDistanceBtn.selected = NO;
    self.currentDistanceBtn = sender;
    self.preDistanceButton.selected = NO;
    sender.selected = YES;
    self.preDistanceButton = self.currentDistanceBtn;
    self.distance = (int)self.currentDistanceBtn.tag;
}

/** 点击筛选确认按钮 */
- (IBAction)clickFinishBtn:(id)sender
{
    self.selectView.hidden = YES;
    [self.mapView removeAnnotations:self.mapView.annotations];
    self.userLocation.coordinate = self.mapView.centerCoordinate;
    [self sendRequestToServerWithUserLocation:self.userLocation];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [ParkDataManager shareAllCities];
    /** 设置mapView */
    [self setupMapView];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(startDrawLine:) name:@"drawLine" object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(startNavigate:) name:@"clickBtnToStartNavigate" object:nil];
}

/** 画线 */
-(void)startDrawLine:(NSNotification *)notification
{
//    [MBProgressHUD showMessage:@"正在规划路线"];
    [MBProgressHUD showMessage:@"正在规划路线" toView:self.mapView];
    [self.mapView removeOverlay:self.route.polyline];
    CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake([notification.userInfo[@"WD"] doubleValue], [notification.userInfo[@"JD"] doubleValue]);
    MKMapItem *startItem = [MKMapItem mapItemForCurrentLocation];
    MKMapItem *targetItem = [[MKMapItem alloc] initWithPlacemark:[[MKPlacemark alloc] initWithCoordinate:coordinate addressDictionary:nil]];
    MKDirectionsRequest *request = [MKDirectionsRequest new];
    request.source = startItem;
    request.destination = targetItem;
    MKDirections *directions = [[MKDirections alloc] initWithRequest:request];
    [directions calculateDirectionsWithCompletionHandler:^(MKDirectionsResponse * _Nullable response, NSError * _Nullable error) {
        if (!error)
        {
            NSArray *routesArray = response.routes;
            for (MKRoute *route in routesArray)
            {
                [self.mapView addOverlay:route.polyline];
                self.route = route;
                if (self.route != nil)
                {
                    [MBProgressHUD hideHUDForView:self.mapView];
                }
                NSArray *stepsArray = route.steps;
                for (MKRouteStep *step in stepsArray)
                {
                    NSLog(@"描述:%@; 距离:%f",step.instructions, step.distance);
                }
            }
        }
    }];
    self.naviButton.hidden = NO;
}

/** 设置画线的粗细颜色 */
-(MKOverlayRenderer *)mapView:(MKMapView *)mapView rendererForOverlay:(id<MKOverlay>)overlay
{
    MKPolylineRenderer *line = [[MKPolylineRenderer alloc] initWithOverlay:overlay];
    line.strokeColor = [UIColor greenColor];
    line.lineWidth = 3;
    return line;
}

/** 设置mapView */
- (void)setupMapView
{
    self.manager = [CLLocationManager new];
    [self.manager requestAlwaysAuthorization];
    self.mapView.delegate = self;
    self.mapView.rotateEnabled = NO;
    self.mapView.mapType = MKMapTypeStandard;
    self.mapView.userTrackingMode = MKUserTrackingModeFollow;
}

#pragma mark - MapViewDelegate
/** 已经定位到用户位置并且显示完毕 */
- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    userLocation.title = @"当前位置";
    
    CLLocation *current = [[CLLocation alloc ]initWithLatitude:userLocation.coordinate.latitude longitude:userLocation.coordinate.longitude];
    CLLocation *previous = [[CLLocation alloc]initWithLatitude:self.previousUserLocation.coordinate.latitude longitude:self.previousUserLocation.coordinate.longitude];
    CLLocationDistance distance = [current distanceFromLocation:previous];
    MYLog(@"用户移动了 %lf 米", distance);
    /** 如果用户点击了筛选距离 */
    if (self.distance)
    {
        if (distance >= self.distance)
        {
            /** 移除之前的大头针 */
            [self.mapView removeAnnotations:self.mapView.annotations];
            /** 当前新的位置，重新加载停车场 */
            [self sendRequestToServerWithUserLocation:userLocation];
            self.previousUserLocation = current;
        }
    }
    /** 如果用户没有点击筛选距离 */
    else
    {
        if (distance >= 1000)
        {
            /** 移除之前的大头针 */
            [self.mapView removeAnnotations:self.mapView.annotations];
            /** 当前新的位置，重新加载停车场 */
            [self sendRequestToServerWithUserLocation:userLocation];
            self.previousUserLocation = current;
        }
    }
}

/** 向服务器发送请求 */
- (void)sendRequestToServerWithUserLocation:(MKUserLocation *)userLocation
{
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[@"key"] = APPKEY;
    parameters[@"JD"] = @(userLocation.coordinate.longitude);
    parameters[@"WD"] = @(userLocation.coordinate.latitude);
    if (self.category)
    {
        parameters[@"TCCFL"] = @(self.category);
    }
    if (self.distance)
    {
        parameters[@"JLCX"] = @(self.distance);
    }
    else
    {
        parameters[@"JLCX"] = @(1000);
    }
    parameters[@"SDXX"] = @(1);
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager POST:NEARPARK parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        MYLog(@"请求成功：%@", responseObject);
        /** 分线程读取数据 */
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            /** 解析返回的数据 */
            if ([responseObject isKindOfClass:[NSDictionary class]])
            {
                NSString *parksArrayPath = [DOCPATH stringByAppendingPathComponent:@"parks.plist"];
                [responseObject writeToFile:parksArrayPath atomically:YES];
                self.nearbyParksArray = [ParkDataManager getNearbyParksFromServer:responseObject];
                if (self.nearbyParksArray.count == 0)
                {
                    sleep(5);
                    [self addAlert];
                }
                MYLog(@"%@", self.nearbyParksArray);
                /** 添加大头针 */
                [self addAnnotationsForParks:self.nearbyParksArray];
            }
        });
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD showError:@"网络错误，请稍后再试"];
    }];
}

/** 如果附近没有停车场，弹出提示框 */
-(void)addAlert
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"附近没有可用停车场" message:@"请移动地图查看周围，或者搜索目的地" preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *doneAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
    [alertController addAction:doneAction];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [self presentViewController:alertController animated:YES completion:nil];
    });
    
}

/** 监听到地图发生移动 */
- (void) mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated
{
//    MYLog(@"地图发生移动");
//    CLLocationCoordinate2D center = self.mapView.centerCoordinate;
//    CLLocation *currentLocation = [[CLLocation alloc] initWithLatitude:center.latitude longitude:center.longitude];
//    CLLocation *previousLocation = [[CLLocation alloc] initWithLatitude:self.previousUserLocation.coordinate.latitude longitude:self.previousUserLocation.coordinate.longitude];
//    
//    CLLocationDistance distance = [currentLocation distanceFromLocation:previousLocation];
//    MYLog(@"distance: %f", distance);
//    if (distance >= 1000.0)
//    {
//        /** 移除之前的大头针 */
//        [self.mapView removeAnnotations:self.mapView.annotations];
//        /** 当前新的位置，重新加载停车场 */
//        [self sendRequestToServerWithUserLocation:(MKUserLocation *)currentLocation];
//        self.previousUserLocation = currentLocation;
//    }
    
}

#pragma mark - 添加大头针
-(void) addAnnotationsForParks:(NSArray *)nearbyParksArray
{
    //设置对象的三个属性
    for (ParkNearbyParks *nearbyParks in nearbyParksArray)
    {
        ParkAnnotation *annotation = [ParkAnnotation new];
        CLLocationDegrees latitude = nearbyParks.WD;
        CLLocationDegrees longitude = nearbyParks.JD;
        annotation.coordinate = CLLocationCoordinate2DMake(latitude, longitude);
        annotation.title = nearbyParks.CCMC;
        annotation.subtitle = [NSString stringWithFormat:@"总车位:%@  空车位:%@", nearbyParks.ZCW, nearbyParks.KCW];
        annotation.ccid = [nearbyParks.CCID intValue];
        annotation.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://images.juheapi.com/park/%@", nearbyParks.KCWZT]]]];
        dispatch_async(dispatch_get_main_queue(), ^{
            //添加到地图视图上(必须遵守MKAnnotation协议)
            [self.mapView addAnnotation:annotation];
        });
    }
}

/** 给大头针显示自定义图片：空车位状态图 */
- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    
    if ([annotation isKindOfClass:[MKUserLocation class]])
    {
        return nil;
    }
    
    static NSString *identifier = @"annoView";
    MKAnnotationView *annoView = [mapView dequeueReusableAnnotationViewWithIdentifier:identifier];
    if (!annoView)
    {
        annoView = [[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:identifier];
        annoView.canShowCallout = YES;
        annoView.rightCalloutAccessoryView = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
    }

    annoView.annotation = annotation;
    ParkAnnotation *anno = (ParkAnnotation *)annotation;
    annoView.image = anno.image;
  
    return annoView;
}

/** 使大头针坠落 */
- (void)mapView:(MKMapView *)mapView didAddAnnotationViews:(NSArray *)annotationViews
{
    MKAnnotationView *annoView = [MKAnnotationView new];
    CGRect visibleRect = [mapView annotationVisibleRect];
    for (annoView in annotationViews)
    {
        /** 如果是用户位置就不坠落 */
        if ([annoView.annotation isKindOfClass:[MKUserLocation class]])
        {
            continue;
        }
        CGRect endFrame = annoView.frame;
        CGRect startFrame = endFrame;
        startFrame.origin.y = visibleRect.origin.y - startFrame.size.height;
        annoView.frame = startFrame;
        [UIView beginAnimations:@"drop" context:NULL];
        [UIView setAnimationDuration:0.4];
        annoView.frame = endFrame;
        [UIView commitAnimations];
    }
}

/** 添加点击事件 */
- (void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view calloutAccessoryControlTapped:(UIControl *)control
{
    [MBProgressHUD showMessage:@"Loading..."];
    ParkAnnotation *annotation = view.annotation;
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[@"key"] = APPKEY;
    parameters[@"CCID"] = @(annotation.ccid);
    
    /** 请求停车场详情 */
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager POST:BASEINFO parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        MYLog(@"请求成功：%@", responseObject);
        /** 解析返回的数据 */
        if ([responseObject isKindOfClass:[NSDictionary class]])
        {
            self.parkBaseInfo = [ParkDataManager getAndParseAllBaseInfoFrom:responseObject];
            
            MYLog(@"parkBaseInfo:%@", self.parkBaseInfo);
    
            ParkNearbyParksDetailTableViewController *parkDetailsVC = [ParkNearbyParksDetailTableViewController new];
            parkDetailsVC.baseInfo = self.parkBaseInfo;
            if (parkDetailsVC.baseInfo != nil)
            {
                [MBProgressHUD hideHUD];
            }
            UINavigationController *navi = [[UINavigationController alloc] initWithRootViewController:parkDetailsVC];
            [self presentViewController:navi animated:YES completion:nil];
        }
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD showError:@"网络错误，请稍后再试"];
    }];
}

/** 点击筛选按钮 */
- (IBAction)clickSelectButton:(id)sender
{
    self.selectView.hidden = !self.selectView.hidden;
}

- (IBAction)clickChangeCityButton:(id)sender
{
    ParkChangeCityTableViewController *changeCityVC = [ParkChangeCityTableViewController new];
    UINavigationController *naviController = [[UINavigationController alloc] initWithRootViewController:changeCityVC];
    changeCityVC.ChangeCityBlock = ^(NSString *cityName) {
        self.cityNameLabel.text = cityName;
        self.destinationTextField.text = cityName;
        [self geocoderCityName:cityName];
    };
    [self presentViewController:naviController animated:YES completion:nil];
}

/** 地理编码, 得到选中城市的经纬度 */
- (void)geocoderCityName:(NSString *)cityName
{
    [self.geocoder geocodeAddressString:cityName completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        if (!error)
        {
            for (CLPlacemark *placemark in placemarks)
            {
                MYLog(@"%f, %f", placemark.location.coordinate.latitude, placemark.location.coordinate.longitude);
                [self.mapView setCenterCoordinate:placemark.location.coordinate];
                [self sendRequestToServerWithPlacemarkLocation:placemark];
            }
        }
    }];
}

/** 点击键盘search按钮的响应事件 */
- (IBAction)searchDestinationParks:(id)sender
{
    NSString *cityName = self.destinationTextField.text;
    [self geocoderCityName:cityName];
}

/** 用选中城市通过地理编码得到的经纬度重新发请求 */
- (void)sendRequestToServerWithPlacemarkLocation:(CLPlacemark *)placemark
{
    /** 移除之前的大头针 */
    [self.mapView removeAnnotations:self.mapView.annotations];
    
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[@"key"] = APPKEY;
    parameters[@"JD"] = @(placemark.location.coordinate.longitude);
    parameters[@"WD"] = @(placemark.location.coordinate.latitude);
    if (self.category)
    {
        parameters[@"TCCFL"] = @(self.category);
    }
    if (self.distance)
    {
        parameters[@"JLCX"] = @(self.distance);
    }
    else
    {
        parameters[@"JLCX"] = @(1000);
    }

    parameters[@"SDXX"] = @(1);
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    [manager POST:NEARPARK parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
        MYLog(@"请求成功：%@", responseObject);
        /** 分线程解析数据 */
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            /** 解析返回的数据 */
            if ([responseObject isKindOfClass:[NSDictionary class]])
            {
                NSString *parksArrayPath = [DOCPATH stringByAppendingPathComponent:@"parks.plist"];
                [responseObject writeToFile:parksArrayPath atomically:YES];
                self.nearbyParksArray = [ParkDataManager getNearbyParksFromServer:responseObject];
                if (self.nearbyParksArray.count == 0)
                {
                    sleep(5);
                    [self addAlert];
                }
                MYLog(@"%@", self.nearbyParksArray);
                /** 添加大头针 */
                [self addAnnotationsForParks:self.nearbyParksArray];
            }
        });
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        [MBProgressHUD showError:@"网络错误，请稍后再试"];
    }];

}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
    self.selectView.hidden = YES;
}

/** 导航通知 */
-(void)startNavigate:(NSNotification *)notification
{
    CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake([notification.userInfo[@"WD"] doubleValue], [notification.userInfo[@"JD"] doubleValue]);
    self.naviCoordinate = coordinate;
    self.parkItemName = notification.userInfo[@"CCMC"];
}

/** 开始导航 */
- (IBAction)clickNaviBtn:(id)sender
{
    CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(self.naviCoordinate.latitude, self.naviCoordinate.longitude);
    MKMapItem *currentItem = [MKMapItem mapItemForCurrentLocation];
    MKMapItem *parkItem = [[MKMapItem alloc] initWithPlacemark:[[MKPlacemark alloc] initWithCoordinate:coordinate addressDictionary:nil]];
    parkItem.name = self.parkItemName;
    NSDictionary *options=@{MKLaunchOptionsMapTypeKey:@(MKMapTypeStandard),MKLaunchOptionsDirectionsModeKey:MKLaunchOptionsDirectionsModeDriving};
    [MKMapItem openMapsWithItems:@[currentItem, parkItem] launchOptions:options];
}







- (MKRoute *)route
{
    if(_route == nil)
    {
        _route = [[MKRoute alloc] init];
    }
    return _route;
}

- (CLLocation *)beforeLocation
{
    if(_previousUserLocation == nil)
    {
        _previousUserLocation = [[CLLocation alloc] initWithLatitude:self.mapView.userLocation.coordinate.latitude longitude:self.mapView.userLocation.coordinate.longitude];
    }
    return _previousUserLocation;
}

- (MKUserLocation *)userLocation
{
    if(_userLocation == nil)
    {
        _userLocation = [[MKUserLocation alloc] init];
    }
    return _userLocation;
}

- (CLGeocoder *)geocoder
{
    if (!_geocoder)
    {
        _geocoder = [CLGeocoder new];
    }
    return _geocoder;
}

@end
