//
//  ParkTabBarViewController.m
//  易停 easy parking
//
//  Created by tarena on 16/1/27.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ParkTabBarViewController.h"

@interface ParkTabBarViewController ()


@end

@implementation ParkTabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
