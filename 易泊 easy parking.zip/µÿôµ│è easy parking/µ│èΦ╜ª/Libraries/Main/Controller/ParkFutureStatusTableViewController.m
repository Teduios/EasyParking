//
//  ParkFutureStatusTableViewController.m
//  易停 easy parking
//
//  Created by tarena on 16/1/25.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ParkFutureStatusTableViewController.h"
#import "ParksStatus.h"
#import "UIImageView+WebCache.h"

@interface ParkFutureStatusTableViewController ()

@end

@implementation ParkFutureStatusTableViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.title = @"车位预测";
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStyleDone target:self action:@selector(goBack)];
    self.navigationItem.leftBarButtonItem = leftItem;
    [self.tableView reloadData];
}

-(void)goBack
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.futureStatusArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"statusCell"];
    if (!cell)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"statusCell"];
    }
    ParksStatus *status = self.futureStatusArray[indexPath.row];
    cell.textLabel.text = status.YCSJ;
//    cell.imageView.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://images.juheapi.com/park/%@", status.KCWZT]]]];
    [cell.imageView setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://images.juheapi.com/park/%@", status.KCWZT]]];
    /** 取出KCWZT的P1001.png的第四位1 */
    NSString *KCWZT = status.KCWZT;
    NSRange range = {4, 1};
    NSString *string = [KCWZT substringWithRange:range];
    switch ([string integerValue])
    {
        case 1:
            cell.detailTextLabel.text = @"车位充足";
            break;
        case 2:
            cell.detailTextLabel.text = @"车位够用";
            break;
        case 3:
            cell.detailTextLabel.text = @"车位较少";
            break;
        case 4:
            cell.detailTextLabel.text = @"车位紧张";
            break;
        case 5:
            cell.detailTextLabel.text = @"车位未知";
            break;
        case 6:
            cell.detailTextLabel.text = @"车位关闭";
            break;
        default:
            break;
    }
    
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
