//
//  WelcomeViewController.m
//  Demo_3 欢迎界面
//
//  Created by tarena on 15/11/22.
//  Copyright (c) 2015年 tarena. All rights reserved.
//

#import "ParkWelcomeViewController.h"
#import "ParkTabBarViewController.h"

@interface ParkWelcomeViewController ()<UIScrollViewDelegate>

@property (nonatomic,strong) UIPageControl *pageControl;


@end

@implementation ParkWelcomeViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setUpScrollView];
    [self setUpPageControl];
}

//定制滚动视图
-(void)setUpScrollView
{
    // 创建滚动视图
    UIScrollView *sv = [[UIScrollView alloc]init];
    
    // 为了捕获滚动视图与用户的交互，需要设置代理
    sv.delegate = self;
    
    // 设置边缘不能弹跳
    sv.bounces = NO;
    
    // 设置滚动视图整页滚动
    sv.pagingEnabled = YES;
    
    // 设置水平滚动条不可见
    sv.showsHorizontalScrollIndicator = NO;
    
    // 设置滚动视图的可见区域
    sv.frame = self.view.bounds;
    
    // 设置contentSiz
    sv.contentSize = CGSizeMake(sv.bounds.size.width * 4, sv.bounds.size.height);
    
    // 添加子视图
    
    for (NSInteger i = 0; i < 4; i++)
    {
        UIImageView *imageView = [[UIImageView alloc]init];
        imageView.frame = CGRectMake(sv.bounds.size.width*i, 0, sv.bounds.size.width, sv.bounds.size.height);
        NSString *fileName = [NSString stringWithFormat:@"EasyPark%ld.png", i+1];
        imageView.image = [UIImage imageNamed:fileName];
        
        [sv addSubview:imageView];
        
        //如果是最后一幅图片，则像其中添加一个按钮
//        if (i == 3)
//        {
//            [self setupEnterButton:imageView];
//        }
        [self setupEnterButton:imageView];
        
    }
    // 添加滚动视图到控制器的view中
    [self.view addSubview:sv];
}

//定制屏幕下方的小圆点
-(void)setUpPageControl
{
    //创建pageControl
    UIPageControl *pageControl = [[UIPageControl alloc]init];
    self.pageControl = pageControl;
    
    //设置frame
    pageControl.frame = CGRectMake(0, self.view.bounds.size.height-50, self.view.bounds.size.width, 30);
    
    //设置圆点的个数
    pageControl.numberOfPages = 4;
    
    //设置圆点的颜色
    pageControl.pageIndicatorTintColor = [UIColor whiteColor];
    
    //设置选中的圆点的颜色
    pageControl.currentPageIndicatorTintColor = [UIColor colorWithRed:239.0/255.0 green:131.0/255.0 blue:10.0/255.0 alpha:1.0];
    
    //设置某个圆点被选中
//    pageControl.currentPage = 2;
    
    //设置圆点不能与用户交互
    pageControl.userInteractionEnabled = NO;
    
    //添加到控制器的view中，盖在滚动视图之上
    [self.view addSubview:pageControl];
}


- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGPoint point = scrollView.contentOffset;
    
    //计算偏移量是滚动视图宽度的整数倍
    //为了在超过一半时，就自动是下一个圆点
    //通过round函数四舍五入即可
    self.pageControl.currentPage = round(point.x/scrollView.bounds.size.width);
    
//    NSLog(@"%@", NSStringFromCGPoint(point));
}

//配置点击进入程序的按钮
-(void)setupEnterButton:(UIImageView *)iv
{
    
    //打开iv的用户交互功能,按钮才能响应点击
    iv.userInteractionEnabled = YES;
    
    UIButton *button = [[UIButton alloc]init];
    button.frame = CGRectMake(50, iv.bounds.size.height*0.8, iv.bounds.size.width - 100, 40);
    [button setTitle:@"Enter" forState:UIControlStateNormal];
    
    //配置按钮的边缘
//    button.layer.borderWidth = 3;
//    button.layer.borderColor = [UIColor whiteColor].CGColor;
    button.layer.cornerRadius = 10;
    
    //增加点击事件
    [button addTarget:self action:@selector(clickEnterButton:) forControlEvents:UIControlEventTouchUpInside];
    
    button.backgroundColor = [UIColor colorWithRed:239.0/255.0 green:131.0/255.0 blue:10.0/255.0 alpha:1.0];
    [iv addSubview:button];
}

//点击进入按钮，推出主界面
-(void)clickEnterButton:(UIButton *)btn
{
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    ParkTabBarViewController *tabBarController = [storyBoard instantiateViewControllerWithIdentifier:@"ParkTabBarViewController"];
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
    //获取在main函数中创建过的那个唯一的应用程序对象
    UIApplication *application = [UIApplication sharedApplication];
    UIWindow *window = application.keyWindow;
    //更换根vc
    window.rootViewController = tabBarController;
    
}

@end
