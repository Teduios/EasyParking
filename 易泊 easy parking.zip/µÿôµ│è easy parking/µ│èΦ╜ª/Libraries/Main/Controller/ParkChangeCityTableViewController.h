//
//  ParkChangeCityTableViewController.h
//  易停 easy parking
//
//  Created by tarena on 16/1/14.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ParkChangeCityTableViewController : UITableViewController

//声明block
@property (nonatomic, copy) void (^ChangeCityBlock)(NSString *cityName);


@end


