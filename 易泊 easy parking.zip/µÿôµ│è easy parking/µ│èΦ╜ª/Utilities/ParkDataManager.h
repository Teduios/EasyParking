//
//  ParkDataManager.h
//  易停 easy parking
//
//  Created by tarena on 16/1/12.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ParkNearbyParkDetails.h"

@interface ParkDataManager : NSObject

/** 返回根据坐标获取附近的停车场 */
+ (NSArray *) getNearbyParksFromServer:(id)responseObj;

+ (NSArray *) shareAllCities;

/** 返回所有城市 */
+ (NSArray *) getAndParseAllCities;

/** 返回根据坐标获取到的附近停车场的详细信息 */
+ (ParkNearbyParkDetails *) getAndParseAllBaseInfoFrom:(id)responseObj;

/** 返回停车场的未来预测指数 */
+ (NSArray *) getAndParseFutureStatusFromServer:(id)responseObj;

@end
