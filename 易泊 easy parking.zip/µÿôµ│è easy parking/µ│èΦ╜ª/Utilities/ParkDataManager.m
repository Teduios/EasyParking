//
//  ParkDataManager.m
//  易停 easy parking
//
//  Created by tarena on 16/1/12.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ParkDataManager.h"
#import "AFNetworking.h"
#import "ParkNearbyParks.h"
#import "ParkCity.h"
#import "ParkNearbyParkDetails.h"
#import "ParksStatus.h"

@implementation ParkDataManager

+(NSArray *) getNearbyParksFromServer:(id)responseObj
{
    /** 获取数据 */
    NSArray *nearbyParksArray = responseObj[@"result"];
    /** 循环将字典转换成模型类 */
    NSMutableArray *nearbyParksMutableArray = [NSMutableArray array];
    for (NSDictionary *nearbyParksDic in nearbyParksArray)
    {
        //Dic -> ParkNearbyParks模型
        ParkNearbyParks *nearbyParks = [ParkNearbyParks new];
        [nearbyParks setValuesForKeysWithDictionary:nearbyParksDic];
        [nearbyParksMutableArray addObject:nearbyParks];
    }
    return [nearbyParksMutableArray copy];
}

static NSArray *_cityArray = nil;
+(NSArray *)shareAllCities
{
    if (!_cityArray)
    {
        _cityArray = [NSArray new];
        NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
        parameters[@"key"] = APPKEY;
        AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
        [manager POST:CITYLIST parameters:parameters success:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            if ([responseObject isKindOfClass:[NSDictionary class]])
            {
                _cityArray = responseObject[@"result"];
                NSString *resultArrayPath = [DOCPATH stringByAppendingPathComponent:@"cities.plist"];
                [_cityArray writeToFile:resultArrayPath atomically:YES];
            }
            
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            MYLog(@"请求失败：%@", error);
        }];

    }
    return _cityArray;
}

+(NSArray *)getAndParseAllCities;
{
    /** 获取数据 */
    NSString *resultArrayPath = [DOCPATH stringByAppendingPathComponent:@"cities.plist"];
    NSArray *citiesArray = [NSArray arrayWithContentsOfFile:resultArrayPath];
    /** 循环将字典转换成模型类 */
    NSMutableArray *mutableArray = [NSMutableArray array];
    for (NSDictionary *cityDic in citiesArray)
    {
        //Dic -> ParkCity模型
        ParkCity *city = [[ParkCity alloc] init];
        [city setValuesForKeysWithDictionary:cityDic];
        [mutableArray addObject:city];
    }
    return [mutableArray copy];
}

/** 解析停车场详细信息 */
+ (ParkNearbyParkDetails *) getAndParseAllBaseInfoFrom:(id)responseObj
{
    NSArray *baseInfoArray = responseObj[@"result"];
    ParkNearbyParkDetails *parkDetails = [ParkNearbyParkDetails new];
    for (NSDictionary *baseInfoDic in baseInfoArray)
    {
        parkDetails = [ParkNearbyParkDetails new];
        [parkDetails setValuesForKeysWithDictionary:baseInfoDic];
    }
    return parkDetails;
}

/** 解析停车场车位预测 */
+ (NSArray *) getAndParseFutureStatusFromServer:(id)responseObj
{
    NSArray *futureStatusArray = responseObj[@"result"];
    NSMutableArray *mutableArray = [NSMutableArray array];
    for (NSDictionary *dic in futureStatusArray)
    {
        ParksStatus *status = [ParksStatus new];
        [status setValuesForKeysWithDictionary:dic];
        [mutableArray addObject:status];
    }
    return [mutableArray copy];
}

@end
